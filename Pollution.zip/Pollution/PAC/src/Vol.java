/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
class Vol {
    
    private int e_id,u_id;
    
    
    public Vol(int e_id,int u_id)
    {
        this.e_id=e_id;
        this.u_id=u_id;
        
        
    }
    public int gete_id()
    {
        return e_id;
    }
     public int getu_id()
    {
        return u_id;
    }
      
}
