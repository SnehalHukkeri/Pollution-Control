/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
class Eve {
    private int p_id,e_id,a_id;
    private String e_name,e_pollution,e_place,e_date;
    
    public Eve(int p_id,int e_id,int a_id,String e_name,String e_pollution,String e_place,String e_date)
    {
        this.p_id=p_id;
        this.e_id=e_id;
        this.a_id=a_id;
        this.e_name=e_name;
        this.e_pollution=e_pollution;
        this.e_place=e_place;
        this.e_date=e_date;
        
    }
    public int getp_id()
    {
        return p_id;
    }
    public int gete_id()
    {
        return e_id;
    }
     public int geta_id()
    {
        return a_id;
    }
      public String gete_name()
    {
        return e_name;
    }
       public String gete_pollution()
    {
        return e_pollution;
    }
        public String gete_place()
    {
        return e_place;
    }
        public String gete_date()
    {
        return e_date;
    }
}
