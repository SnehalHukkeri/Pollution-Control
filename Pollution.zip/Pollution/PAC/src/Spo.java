/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
class Spo {
    private int e_id,u_id,amount;
    //private String r_matrials,r_volunteers;
    
    public Spo(int e_id,int u_id,int amount)
    {
        this.e_id=e_id;
        this.u_id=u_id;
        this.amount=amount;
       //1 this.r_money=r_money;
      //  this.r_matrials=r_matrials;
       // this.r_volunteers=r_volunteers;
        
    }
    public int gete_id()
    {
        return e_id;
    }
     public int getu_id()
    {
        return u_id;
    }
      public int getamount()
      {
          return amount;
      }
}
